var a00098 =
[
    [ "check_links_light_test", "da/d74/a00099.html", "da/d74/a00099" ],
    [ "numfiles_maxvalue_light_test", "d0/d61/a00100.html", "d0/d61/a00100" ],
    [ "numfiles_minvalue_light_test", "d4/d3a/a00101.html", "d4/d3a/a00101" ],
    [ "numfiles_samevalue_light_test", "d9/dcc/a00102.html", "d9/dcc/a00102" ],
    [ "search_download_light_test", "d5/d1e/a00103.html", "d5/d1e/a00103" ]
];