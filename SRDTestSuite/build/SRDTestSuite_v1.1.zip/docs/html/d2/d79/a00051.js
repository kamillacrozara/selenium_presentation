var a00051 =
[
    [ "assert_search_result", "d2/d79/a00051.html#a4275d9f564df62c76b97acb1459a4d72", null ],
    [ "assert_title", "d2/d79/a00051.html#acff10b4cb51d7d9e653d12b5292c8c30", null ],
    [ "count_test_cases_in_page", "d2/d79/a00051.html#a089f935ca0c6bb58948af7f45341d8f0", null ],
    [ "go_last_page", "d2/d79/a00051.html#a15a55522db88f61be34c2f081c475bc8", null ]
];