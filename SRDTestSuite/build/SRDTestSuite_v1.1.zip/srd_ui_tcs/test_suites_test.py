#!/usr/bin/python
# -*- coding: utf-8 *-*

##@package srd_ui_tcs
# Package with automated User Interface tests using 
# Selenium Webdriver

##@file test_suites_test.py
# @brief Test cases of "Test Suites" SRD page
# @ingroup suite_srd_ui


from selenium import webdriver
from common_ui_tests import common_ui_tests
import unittest, time, re

##@brief This class has user interface tests to the "Test Suites" page
class TCTestSuites(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        self.driver.implicitly_wait(30)
        config = {}
        execfile("srd_selenium_tests.conf", config)
        self.base_url = config["BASE_URL"]
        self.verificationErrors = []
        self.accept_next_alert = True
    
    ##@brief This method executes tests to verify the elements on the "Test Suites" page
    def test_t_c_test_suites(self):
        driver = self.driver
        driver.get(self.base_url + "/index.php")
        driver.find_element_by_xpath("//a[contains(text(),'Test Suites')]").click()
        time.sleep(2)
        self.assertEqual("SAMATE Reference Dataset", driver.title)
       
        common_ui_tests.testSRDMenu(self, driver, self.verificationErrors)

        self.assertEqual("Test Suites", driver.find_element_by_xpath("//div[@id='content']/h1").text)
        self.assertEqual("Stand-alone Suites", driver.find_element_by_xpath("//div[@id='content']/h2").text)
        self.assertEqual("SRD Suites", driver.find_element_by_xpath("//div[@id='content']/h2[2]").text)
        self.assertEqual("Archives", driver.find_element_by_xpath("//div[@id='content']/h2[3]").text)
       
       
        common_ui_tests.testFooter(self, driver, self.verificationErrors)
    
    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
