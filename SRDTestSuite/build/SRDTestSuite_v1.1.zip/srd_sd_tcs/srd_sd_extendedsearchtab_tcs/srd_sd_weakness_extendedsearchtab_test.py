#!/usr/bin/python
# -*- coding: utf-8 *-*

##@package srd_sd_tcs
# Package with automated Search/Download tab tests using 
# Selenium Webdriver

##@file srd_sd_weakness_extendedsearchtab_test.py
# @brief Test Cases inserting to verify the search by weakness on Extended Search tab
# @ingroup suite_srd_sd
from selenium import webdriver
import unittest, time, re
from srd_sd_tcs.common_sd_methods import common_sd_methods

##@brief This class executes tests about the searchs by weakness on the "Extended Search" tab
class SrdSdWeaknessExtendedSearchTabTc(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        self.driver.implicitly_wait(5)
        config = {}
        execfile("srd_selenium_tests.conf", config)
        self.base_url = config["BASE_URL"]
        self.verificationErrors = []
        self.accept_next_alert = True

    ##@brief This method verifies the results of searches by weakness
    def test_srd_sd_weakness_extendedsearchtab_tc(self):
        driver = self.driver

        self.get_page(driver, "/view.php?fromWhere=fromSearch&flaw=CWE-843%3A+Access+of+Resource+Using+Incompatible+Type+%28Type+Confusion%29&codecplx=Any...&reference=&description=&author=&contributor=&flawed[]=Any...&languages[]=Any...&typesofartifacts[]=Any...&status_Candidate=1&status_Approved=1&flaw_ro=CWE-843%3A+Access+of+Resource+Using+Incompatible+Type+%28Type+Confusion%29&codecplx_ro=Any...&date=&typeDate=Any...&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)

        numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
        self.verify_weakness(driver, numOfTestCases, "CWE-843: Access of Resource Using Incompatible Type (Type Confusion)")
        
        self.get_page(driver, "/view.php?fromWhere=fromSearch&flaw=CWE-835%3A+Loop+with+Unreachable+Exit+Condition+%28Infinite+Loop%29&codecplx=Any...&reference=&description=&author=&contributor=&flawed[]=Any...&languages[]=Any...&typesofartifacts[]=Any...&status_Candidate=1&status_Approved=1&typesofflaws_1=CWE-835%3A+Loop+with+Unreachable+Exit+Condition+%28Infinite+Loop%29&codecplx_1=Any...&date=&typeDate=Any...&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)

        numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
        self.verify_weakness(driver, numOfTestCases, "CWE-835: Loop with Unreachable Exit Condition (Infinite Loop)")


        self.get_page(driver, "/view.php?fromWhere=fromSearch&flaw=CWE-506%3A+Embedded+Malicious+Code&codecplx=Any...&reference=&description=&author=&contributor=&flawed[]=Any...&languages[]=Any...&typesofartifacts[]=Any...&status_Candidate=1&status_Approved=1&typesofflaws_1=CWE-506%3A+Embedded+Malicious+Code&codecplx_1=Any...&date=&typeDate=Any...&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)

        numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
        self.verify_weakness(driver, numOfTestCases, "CWE-506: Embedded Malicious Code")

        self.get_page(driver, "/view.php?fromWhere=fromSearch&flaw=CWE-170%3A+Improper+Null+Termination&codecplx=Any...&reference=&description=&author=&contributor=&flawed[]=Any...&languages[]=Any...&typesofartifacts[]=Any...&status_Candidate=1&status_Approved=1&typesofflaws_1=CWE-170%3A+Improper+Null+Termination&codecplx_1=Any...&date=&typeDate=Any...&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)

        numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
        self.verify_weakness(driver, numOfTestCases, "CWE-170: Improper Null Termination")

        self.get_page(driver, "/view.php?fromWhere=fromSearch&flaw=CWE-330+Insufficiently+Random+Values&codecplx=Any...&reference=&description=&author=&contributor=&flawed[]=Any...&languages[]=Any...&typesofartifacts[]=Any...&status_Candidate=1&status_Approved=1&typesofflaws_1=CWE-330+Insufficiently+Random+Values&codecplx_1=Any...&date=&typeDate=Any...&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)

        numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
        self.verify_weakness(driver, numOfTestCases, "CWE-336: Same Seed in PRNG")


    def get_page(self, driver, url):
        driver.get(self.base_url + url)
        time.sleep(2)


    def verify_weakness(self, driver, numOfTestCases, weaknessType):
        i = 2
        while(i < numOfTestCases):
            try: self.assertEqual(weaknessType, driver.find_element_by_xpath("//div[@id='content']/form/table/tbody/tr[%s]/td[8]" %i).text)
            except AssertionError as e: self.verificationErrors.append(str(e))
            i +=1

    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()