#!/usr/bin/python
# -*- coding: utf-8 *-*

##@package srd_sd_tcs
# Package with automated Search/Download tab tests using 
# Selenium Webdriver

##@file srd_sd_dropdown_test.py
# @brief Test Cases to verify the searches using the dropdown menus options 
# @ingroup suite_srd_sd
from selenium import webdriver
import unittest, time, re
from srd_sd_tcs.common_sd_methods import common_sd_methods

##@brief This class executes tests with the dropdown menus options on the "Extended Search" tab
class SrdSdDropDownSearchTabTc(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        self.driver.implicitly_wait(5)
        config = {}
        execfile("srd_selenium_tests.conf", config)
        self.base_url = config["BASE_URL"]
        self.verificationErrors = []
        self.accept_next_alert = True

    ##@brief This method verifies the results of searches using the dropdown menus
    def test_srd_sd_dropdown_tc(self):
        driver = self.driver

        driver.get(self.base_url + "/view.php?fromWhere=fromSearch&flaw=Any...&codecplx=Any...&reference=&description=&author=&contributor=&flawed[]=Bad&languages[]=Any...&typesofartifacts[]=Any...&status_Candidate=1&status_Approved=1&flaw_ro=Any...&codecplx_ro=Any...&date=&typeDate=Any...&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
        self.verify_flawed_element(driver, numOfTestCases, "Bad test case")
        
        if common_sd_methods.go_last_page(driver):
            numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
            self.verify_flawed_element(driver, numOfTestCases, "Bad test case")

        driver.get(self.base_url + "/view.php?fromWhere=fromSearch&flaw=Any...&codecplx=Any...&reference=&description=&author=&contributor=&flawed[]=Good&languages[]=Any...&typesofartifacts[]=Any...&status_Candidate=1&status_Approved=1&flaw_ro=Any...&codecplx_ro=Any...&date=&typeDate=Any...&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)

        numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
        self.verify_flawed_element(driver, numOfTestCases, "Good test case")
        
        if common_sd_methods.go_last_page(driver):
            numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
            self.verify_flawed_element(driver, numOfTestCases, "Good test case")

        driver.get(self.base_url + "/view.php?fromWhere=fromSearch&flaw=Any...&codecplx=Any...&reference=&description=&author=&contributor=&flawed[]=Mixed&languages[]=Any...&typesofartifacts[]=Any...&status_Candidate=1&status_Approved=1&flaw_ro=Any...&codecplx_ro=Any...&date=&typeDate=Any...&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
 
        numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
        self.verify_flawed_element(driver, numOfTestCases, "Mixed test case")
        
        if common_sd_methods.go_last_page(driver):
            numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
            self.verify_flawed_element(driver, numOfTestCases, "Mixed test case")

        driver.get(self.base_url + "/view.php?fromWhere=fromSearch&flaw=Any...&codecplx=Any...&reference=&description=&author=&contributor=&flawed[]=Any...&languages[]=C&typesofartifacts[]=Any...&status_Candidate=1&status_Approved=1&flaw_ro=Any...&codecplx_ro=Any...&date=&typeDate=Any...&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
        self.verify_language_element(driver, numOfTestCases, "C")
        
        if common_sd_methods.go_last_page(driver):
            numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
            self.verify_language_element(driver, numOfTestCases, "C")

        driver.get(self.base_url + "/view.php?fromWhere=fromSearch&flaw=Any...&codecplx=Any...&reference=&description=&author=&contributor=&flawed[]=Any...&languages[]=Java&typesofartifacts[]=Any...&status_Candidate=1&status_Approved=1&flaw_ro=Any...&codecplx_ro=Any...&date=&typeDate=Any...&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
        self.verify_language_element(driver, numOfTestCases, "Java")
        if common_sd_methods.go_last_page(driver):
            numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
            self.verify_language_element(driver, numOfTestCases, "Java")

        driver.get(self.base_url + "/view.php?fromWhere=fromSearch&flaw=Any...&codecplx=Any...&reference=&description=&author=&contributor=&flawed[]=Any...&languages[]=C%2B%2B&typesofartifacts[]=Any...&status_Candidate=1&status_Approved=1&flaw_ro=Any...&codecplx_ro=Any...&date=&typeDate=Any...&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
        self.verify_language_element(driver, numOfTestCases, "C++")
        
        if common_sd_methods.go_last_page(driver):
            numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
            self.verify_language_element(driver, numOfTestCases, "C++")

        driver.get(self.base_url + "/view.php?fromWhere=fromSearch&flaw=Any...&codecplx=Any...&reference=&description=&author=&contributor=&flawed[]=Any...&languages[]=PHP&typesofartifacts[]=Any...&status_Candidate=1&status_Approved=1&flaw_ro=Any...&codecplx_ro=Any...&date=&typeDate=Any...&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
        self.verify_language_element(driver, numOfTestCases, "PHP")
        
        if common_sd_methods.go_last_page(driver):
            numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
            self.verify_language_element(driver, numOfTestCases, "PHP")

        driver.get(self.base_url + "/view.php?fromWhere=fromSearch&flaw=Any...&codecplx=Any...&reference=&description=&author=&contributor=&flawed[]=Any...&languages[]=Any...&typesofartifacts[]=Source+Code&status_Candidate=1&status_Approved=1&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
        self.verify_artifact_element(driver, numOfTestCases, "Source Code")
        
        if common_sd_methods.go_last_page(driver):
            numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
            self.verify_artifact_element(driver, numOfTestCases, "Source Code")

        driver.get(self.base_url + "/view.php?fromWhere=fromSearch&flaw=Any...&codecplx=Any...&reference=&description=&author=&contributor=&flawed[]=Any...&languages[]=Any...&typesofartifacts[]=Mix+Of+Artifact&status_Candidate=1&status_Approved=1&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
        self.verify_artifact_element(driver, numOfTestCases, "Mix Of Artifact")
        
        if common_sd_methods.go_last_page(driver):
            numOfTestCases = common_sd_methods.count_test_cases_in_page(driver)
            self.verify_artifact_element(driver, numOfTestCases, "Mix Of Artifact")

    def go_last_page(self, driver):
        try:
            driver.find_element_by_xpath("//a[contains(text(),'Last')]").click()
            time.sleep(5)
            return True
        except:
            return None
        
    def verify_language_element(self, driver, numOfTestCases, language):
        i = 2
        while(i < numOfTestCases):
            try: self.assertEqual(language, driver.find_element_by_xpath("//div[@id='content']/form/table/tbody/tr[%i]/td[4]" %i).text) 
            except AssertionError as e: self.verificationErrors.append(str(e))
            i +=1

    def verify_flawed_element(self, driver, numOfTestCases, testCaseType):
        i = 2
        while(i < numOfTestCases):
            try: self.assertEqual(testCaseType, driver.find_element_by_xpath("//div[@id='content']/form/table/tbody/tr[%s]/td[9]/a/img" %i).get_attribute('alt')) 
            except AssertionError as e: self.verificationErrors.append(str(e))
            i +=1

    def verify_artifact_element(self, driver, numOfTestCases, artifactType):
        i = 2
        while(i < numOfTestCases):
            try: self.assertEqual(artifactType, driver.find_element_by_xpath("//div[@id='content']/form/table/tbody/tr[%s]/td[5]" %i).text)
            except AssertionError as e: self.verificationErrors.append(str(e))
            i +=1
    
    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()