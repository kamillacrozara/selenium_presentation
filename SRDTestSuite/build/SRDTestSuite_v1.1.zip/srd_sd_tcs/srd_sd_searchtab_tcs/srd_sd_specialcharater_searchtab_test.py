#!/usr/bin/python
# -*- coding: utf-8 *-*

##@package srd_sd_tcs
# Package with automated Search/Download tab tests using 
# Selenium Webdriver

##@file srd_sd_specialcharater_searchtab_test.py
# @brief Test Cases inserting special characters in fields of the Search tab
# @ingroup suite_srd_sd
from selenium import webdriver
import unittest, time, re
from srd_sd_tcs.common_sd_methods import common_sd_methods

##@brief This class executes tests inserting special characters in the fields on the "Search" tab
class SrdSdSpecialcharaterTc(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        self.driver.implicitly_wait(30)
        config = {}
        execfile("srd_selenium_tests.conf", config)
        self.base_url = config["BASE_URL"]
        self.verificationErrors = []
        self.accept_next_alert = True

    ##@brief This method verifies the results of the special characters searches
    def test_srd_sd_specialcharater_tc(self):
        driver = self.driver
        driver.get(self.base_url + "/search.php?simple")

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("\"This sentence is wrapped in double quotes.\"")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("\"This sentence is wrapped in double quotes.\"")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("\"This sentence is wrapped in double quotes.\"")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)

        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='contributor']").send_keys("\"This sentence is wrapped in double quotes.\"")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("'single quotes'")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("'single quotes'")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("'single quotes'")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='contributor']").send_keys("'single quotes'")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("[square brackets]")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("[square brackets]")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("[square brackets]")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='contributor']").send_keys("[square brackets]")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("{curly braces}")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("{curly braces}")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("{curly braces}")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='contributor']").send_keys("{curly braces}")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("<angle brackets>")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("<angle brackets>")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("<angle brackets>")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='contributor']").send_keys("<angle brackets>")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("<!-- XML comment -->")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("<!-- XML comment -->")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("<!-- XML comment -->")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='contributor']").send_keys("<!-- XML comment -->")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("\"quoted\" segment & ampersand")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("\"quoted\" segment & ampersand")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("\"quoted\" segment & ampersand")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='contributor']").send_keys("\"quoted\" segment & ampersand")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("\"A \"quoted\" segment; & (entity); wrapped in quotes\"")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("\"A \"quoted\" segment; & (entity); wrapped in quotes\"")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("\"A \"quoted\" segment; & (entity); wrapped in quotes\"")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='contributor']").send_keys("\"A \"quoted\" segment; & (entity); wrapped in quotes\"")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("\\c:\\mydocs")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("\\c:\\mydocs")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("\\c:\\mydocs")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='contributor']").send_keys("\\c:\\mydocs")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("Hawai`i")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("Hawai`i")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("Hawai`i")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='contributor']").send_keys("Hawai`i")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("#20")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("#20")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("#20")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='contributor']").send_keys("#20")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("\\/")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("\\/")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("\\/")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        driver.back()
        
        driver.find_element_by_xpath("//input[@name='contributor']").send_keys("\\/")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        common_sd_methods.assert_title(self, driver, self.verificationErrors)
        
        driver.back()
    
    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()