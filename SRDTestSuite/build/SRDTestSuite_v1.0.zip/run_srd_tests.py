#!/usr/bin/python
# -*- coding: utf-8 *-*
from threading import Thread, current_thread
import sys, os, fnmatch, time
from datetime import datetime

class SRDStartSuites(Thread):
	def __init__(self, testName, logNumber):
		self.testName = testName
		self.logName = "log/selenium_log_%s_%s.log" %(logNumber, datetime.now().strftime('%m%d%y-%H:%M:%S'))
		#sys.stdout.write("Starting test %s\n" %testName)
		#sys.stdout.flush()
		Thread.__init__(self)
	
	def run(self):
		os.system('python %s -q 2> %s' %(self.testName, self.logName))

def grab_files(dir):
	tests = []
	for root, dirnames, filenames in os.walk(dir):
		for filename in fnmatch.filter(filenames, '*_test.py'):
			tests.append(os.path.join(root, filename))
	return tests

def start_threads(tests):
	#print "Starting SRD Selenium Tests at %s" %datetime.now()
	#start = time.time()
	logNumber = 1
	for test in tests:
		thread = SRDStartSuites(test, logNumber)
		thread.start()
		logNumber +=1
	#print "Elapsed time: %s minutes" %((time.time() - start)/60)

if __name__ == '__main__':
	if len(sys.argv) == 1:
		tests = grab_files(os.getcwd())
		start_threads(tests)
	elif len(sys.argv) == 2:
		if sys.argv[1] == "ui":
			tests = grab_files(os.getcwd() + "/srd_ui_tcs")
			start_threads(tests)
		elif sys.argv[1] == "sd":
			tests = grab_files(os.getcwd() + "/srd_sd_tcs")
			start_threads(tests)
		elif sys.argv[1] == "lt":
			tests = grab_files(os.getcwd() + "/srd_light_tcs")
			start_threads(tests)
		elif sys.argv[1] == "ck":
			tests = grab_files(os.getcwd() + "/srd_checklinks_tcs")
			start_threads(tests)
		
		elif sys.argv[1] == "clean":
			dirs = []
			for root, dirnames, filenames in os.walk(os.getcwd()):
				for filename in fnmatch.filter(dirnames, 'srd_*'):
					dirs.append(os.path.join(root, filename))

			for dir in dirs:
				print "Clean dir %s" %dir
				os.system('cd %s' %dir)
				os.system('rm *.pyc')
		else:
			print "Oops... Wrong argument. Insert only the shortcut to the type of tests you want."

	else:
		print "Oops... Wrong number of arguments. Insert only the shortcut to the type of tests you want."