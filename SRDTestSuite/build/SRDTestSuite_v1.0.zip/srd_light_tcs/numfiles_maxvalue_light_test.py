#!/usr/bin/python
# -*- coding: utf-8 *-*

##@package srd_light_tcs
# Package with automated Search/Download tab tests using 
# Selenium Webdriver

##@file numfiles_maxvalue_light_test.py
# @brief Test Cases searching different values in the min and max number 
# of files fields of the Extended Search tab
# @ingroup suite_light_tcs
from selenium import webdriver
import unittest, time, re


##@brief This class executes tests related to the Number of Files field on Source Code Search tab
class  NumFilesMaxValueLightTest(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        self.driver.implicitly_wait(5)
        config = {}
        execfile("srd_selenium_tests.conf", config)
        self.base_url = config["BASE_URL"]
        self.verificationErrors = []
        self.accept_next_alert = True

    ##@brief This method verifies the results of searchers for values from 0 to 11 to max field    
    def test_srd_sd_numfiles_light_tc_max_value(self):
        driver = self.driver
        self.open_page(driver)
        #11 is the max number of files in a test case
        i = 0
        while True: 
            j = 0
            testCase = 2
            #send the same value for max and min
            driver.find_element_by_xpath("//input[@name='maxFiles']").send_keys("%s" %i)
            driver.find_element_by_xpath("//input[@name='Submit']").click()
            time.sleep(2)
            #count the number of test cases per search
            numOfTestCases = self.count_test_cases(driver)

            if (numOfTestCases == 0):
                driver.back()
            else:
                while(j < numOfTestCases):
                    driver.find_element_by_xpath("//div[@id='content']/form/table/tbody/tr[%s]/td[2]/a" %testCase).click()
                    time.sleep(2)
                    fileString = driver.find_element_by_xpath("//div[@id='content']/table/tbody/tr[14]/td[2]").text
                    
                    try:
                        numOfFiles = re.search('\d+', re.search('The test case contains \d+ files.', fileString).group(0)).group(0)
                    except:
                        numOfFiles = 1
                    
                    if(numOfFiles == 1):
                        try: self.assertTrue(int(numOfFiles) <= i)
                        except AssertionError as e: 
                            self.verificationErrors.append(str(e))
                    else:
                        try: self.assertTrue(int(numOfFiles) <= i)
                        except AssertionError as e: 
                            self.verificationErrors.append(str(e))
                    
                    j += 1
                    testCase += 1
                    driver.back()
                driver.back()
            if (i == 11):
            	break
            i += 11

    ##@brief This method counts the number of test cases in a given page  
    # @param driver Selenium webdriver current object  
    def count_test_cases(self, driver):
        i = 2
        numOfTestCases = 0

        while(True):
            try:
                driver.find_element_by_xpath("//div[@id='content']/form/table/tbody/tr[%s]/td[2]/a" %i)
                numOfTestCases += 1
                i += 1
            except:
                return numOfTestCases

    ##@brief This method opens the "Search/Download > Source Code Search" page 
    # @param driver Selenium webdriver current object  
    def open_page(self, driver):
        driver.get(self.base_url + "/index.php")
        driver.find_element_by_xpath("//a[contains(text(),'SRD Home')]").click()
        driver.find_element_by_xpath("//a[contains(text(),'Search / Download')]").click()
        driver.find_element_by_xpath("//a[contains(text(),'Source Code Search')]").click()
    
    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()