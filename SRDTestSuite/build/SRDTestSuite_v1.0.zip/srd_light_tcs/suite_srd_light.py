#!/usr/bin/python
# -*- coding: utf-8 *-*
##@package srd_light_tcs
# Package with automated SRD Light Test Suite tests using 
# Selenium Webdriver

##@defgroup suite_light_tcs SRD Light Test Suite
# @details Module with SRD basic test cases.

##@file suite_srd_light.py
# @brief Test Suite with light test cases.
# @ingroup suite_light_tcs

import unittest, logging, sys
import check_links_light_test, numfiles_maxvalue_light_test
import numfiles_minvalue_light_test, numfiles_samevalue_light_test
import search_download_light_test

def suite():
	suite = unittest.TestSuite()
	suite.addTest(unittest.makeSuite(check_links_light_test.CheckLinksLightTest))
	
	suite.addTest(unittest.makeSuite(numfiles_maxvalue_light_test.NumFilesMaxValueLightTest))

	suite.addTest(unittest.makeSuite(numfiles_minvalue_light_test.NumFilesMinValueLightTest))

	suite.addTest(unittest.makeSuite(numfiles_samevalue_light_test.NumFilesSameValueLightTest))

	suite.addTest(unittest.makeSuite(search_download_light_test.SearchDownloadLightTest))

	return suite

if __name__ == "__main__":
	unittest.TextTestRunner(verbosity=2).run(suite())
