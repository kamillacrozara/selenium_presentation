 #!/usr/bin/python
# -*- coding: utf-8 *-*

##@package srd_checklinks_tcs
# Package with automated check download links using 
# Selenium Webdriver

##@defgroup suite_srd_ckecklinks SRD Check Links Test Suite
# @details Module with tests to check download links on SRD.

##@file suite_srd_checklinks.py
# @brief Test Cases to verify all the download links in the SRD
# @ingroup suite_srd_ckecklinks
import unittest
import download_all_tcs_test, download_each_tc_test, download_selected_tcs_test

def suite():
	suite = unittest.TestSuite()
	suite.addTest(unittest.makeSuite(download_all_tcs_test.DownloadAllTcs))
	suite.addTest(unittest.makeSuite(download_selected_tcs_test.DownloadSelectedTcs))
	suite.addTest(unittest.makeSuite(download_each_tc_test.DownloadEachTc))

	return suite

if __name__ == "__main__":
	unittest.TextTestRunner(verbosity=2).run(suite())
