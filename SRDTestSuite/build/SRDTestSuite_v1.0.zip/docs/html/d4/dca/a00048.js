var a00048 =
[
    [ "assert_search_result", "d4/dca/a00048.html#a69a7f7682abcfc060779f043aa78fc31", null ],
    [ "assert_title", "d4/dca/a00048.html#ac634af2706398569b51b549938776557", null ]
];