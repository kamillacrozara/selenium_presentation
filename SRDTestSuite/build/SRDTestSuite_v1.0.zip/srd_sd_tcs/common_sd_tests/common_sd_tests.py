#!/usr/bin/python
# -*- coding: utf-8 *-*

##@package srd_sd_tcs
# Package with automated Search/Download tab tests using 
# Selenium Webdriver

##@file common_sd_tests.py
# @brief Common test cases related to the Search/Download tab tests.
# @ingroup suite_srd_sd
def assert_title(self, driver):
        self.assertEqual("SAMATE Reference Dataset :: View all test cases", driver.title)

##@brief method with not found test cases tests 
# @param driver Selenium webdriver current object
def assert_search_result(self, driver):
    try: self.assertEqual("View/Download\nDownloads:     \n\nThere is no such test case in the database! Back to the previous page", driver.find_element_by_xpath("//div[@id='content']").text)
    except AssertionError as e: self.verificationErrors.append(str(e))
    try: self.assertEqual("Back to the previous page", driver.find_element_by_xpath("//a[contains(text(),'Back to the previous page')]").text)
    except AssertionError as e: self.verificationErrors.append(str(e))

if __name__ == '__main__':
	main()
