#!/usr/bin/python
# -*- coding: utf-8 *-*

##@package srd_sd_tcs
# Package with automated Search/Download tab tests using 
# Selenium Webdriver

##@defgroup suite_srd_sd SRD Search/Download Suite
# @details Module with SRD Search/Download test cases.

##@file suite_srd_sd.py
# @brief Test Suite of Search/Downlod tab test cases.
# @ingroup suite_srd_sd
import unittest, logging, sys
from srd_sd_searchtab_tcs import srd_sd_bigstring_searchtab_test
from srd_sd_searchtab_tcs import srd_sd_nonascii_searchtab_test
from srd_sd_searchtab_tcs import srd_sd_specialcharater_searchtab_test

from srd_sd_extendedsearchtab_tcs import srd_sd_bigstring_extendedsearchtab_test
from srd_sd_extendedsearchtab_tcs import srd_sd_nonascii_extendedsearchtab_test
from srd_sd_extendedsearchtab_tcs import srd_sd_specialcharater_extendedsearchtab_test
from srd_sd_extendedsearchtab_tcs import srd_sd_numfiles_extendedsearchtab_test

from srd_sd_sourcecodesearchtab_tcs import srd_sd_bigstring_sourcecodesearchtab_test
from srd_sd_sourcecodesearchtab_tcs import srd_sd_nonascii_sourcecodesearchtab_test
from srd_sd_sourcecodesearchtab_tcs import srd_sd_specialcharater_sourcecodesearchtab_test

##Test suite to SRD Search/Download tab tests
# @brief This method will add all the test cases
# to the suite_srd_sd test suite
# @return suite Object to a test suite with all Search/Download test cases.
def suite():
	suite = unittest.TestSuite()
	suite.addTest(unittest.makeSuite(srd_sd_bigstring_searchtab_test.SrdSdBigstringTc))
	suite.addTest(unittest.makeSuite(srd_sd_nonascii_searchtab_test.SrdSdNonasciiTc))
	suite.addTest(unittest.makeSuite(srd_sd_specialcharater_searchtab_test.SrdSdSpecialcharaterTc))

	suite.addTest(unittest.makeSuite(srd_sd_bigstring_extendedsearchtab_test.SrdSdBigstringExtendedsearchtabTc))
	suite.addTest(unittest.makeSuite(srd_sd_nonascii_extendedsearchtab_test.SrdSdNonasciiExtendedsearchtabTc))
	suite.addTest(unittest.makeSuite(srd_sd_specialcharater_extendedsearchtab_test.SrdSdSpecialcharaterExtendedsearchtabTc))
	suite.addTest(unittest.makeSuite(srd_sd_numfiles_extendedsearchtab_test.SrdSdNumfilesExtendedsearchtabTc))

	suite.addTest(unittest.makeSuite(srd_sd_bigstring_sourcecodesearchtab_test.SrdSdBigstringSourcecodesearchtabTc))
	#suite.addTest(unittest.makeSuite(srd_sd_nonascii_sourcecodesearchtab_tc.SrdSdNonasciiSourcecodesearchtabTc))
	suite.addTest(unittest.makeSuite(srd_sd_specialcharater_sourcecodesearchtab_test.SrdSdSpecialcharaterSourcecodesearchtabTc))

	return suite

if __name__ == "__main__":
	unittest.TextTestRunner(verbosity=2).run(suite())
