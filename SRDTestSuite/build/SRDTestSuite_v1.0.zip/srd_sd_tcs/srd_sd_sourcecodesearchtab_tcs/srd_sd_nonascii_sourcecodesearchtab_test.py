#!/usr/bin/python
# -*- coding: utf-8 *-*

##@package srd_sd_tcs
# Package with automated Search/Download tab tests using 
# Selenium Webdriver

##@file srd_sd_nonascii_sourcecodesearchtab_test.py
# @brief Test Cases inserting non-ascii in fields of the Source Code Search tab
# @ingroup suite_srd_sd

from selenium import webdriver
import unittest, time, re
##@brief This class executes tests inserting non-ascii characters in the fields on the "Search" tab
class SrdSdNonasciiSourcecodesearchtabTc(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        self.driver.implicitly_wait(30)
        config = {}
        execfile("srd_selenium_tests.conf", config)
        self.base_url = config["BASE_URL"]
        self.verificationErrors = []
        self.accept_next_alert = True
        
    ##@brief This method verifies the results of the non-ascii characters searches
    def test_srd_sd_nonascii_sourcecodesearchtab_tc(self):
        driver = self.driver
        driver.get(self.base_url + "/search.php?extended")
        driver.find_element_by_xpath("//a[contains(text(),'SRD Home')]").click()
        driver.find_element_by_xpath("//a[contains(text(),'Search / Download')]").click()
        driver.find_element_by_xpath("//a[contains(text(),'Source Code Search')]").click()
        
        driver.find_element_by_xpath("//input[@id='function']").send_keys(u"ñó? ä?çíì ??/??  ??/?? Huáy?; ?? Zh?ngwén ???????? Lech Wa??sa æøå")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()
        
        driver.find_element_by_xpath("//input[@id='function']").send_keys(u"ñó? ä?çíì ??/??  ??/?? Huáy?; ?? Zh?ngwén ???????? Lech Wa??sa æøå")
        driver.find_element_by_xpath("(//input[@name='precision'])[2]").click()
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()
        
        driver.find_element_by_xpath("//input[@id='fileName']").send_keys(u"ñó? ä?çíì ??/??  ??/?? Huáy?; ?? Zh?ngwén ???????? Lech Wa??sa æøå")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(3)
        self.assert_title(driver)
        
        driver.back()
        
        driver.find_element_by_xpath("//input[@id='fileName']").send_keys(u"ñó? ä?çíì ??/??  ??/?? Huáy?; ?? Zh?ngwén ???????? Lech Wa??sa æøå")
        driver.find_element_by_xpath("//input[@name='searchNameByRegex']").click()
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()
    

    def assert_title(self, driver):
        self.assertEqual("SAMATE Reference Dataset :: View all test cases", driver.title)

    def assert_search_result(self, driver):
        try: self.assertEqual("View/Download\nDownloads:     \n\nThere is no such test case in the database! Back to the previous page", driver.find_element_by_xpath("//div[@id='content']").text)
        except AssertionError as e: self.verificationErrors.append(str(e))
        try: self.assertEqual("Back to the previous page", driver.find_element_by_xpath("//a[contains(text(),'Back to the previous page')]").text)
        except AssertionError as e: self.verificationErrors.append(str(e))

    
    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
