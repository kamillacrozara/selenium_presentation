#!/usr/bin/python
# -*- coding: utf-8 *-*

##@package srd_sd_tcs
# Package with automated Search/Download tab tests using 
# Selenium Webdriver

##@file srd_sd_specialcharater_extendedsearchtab_test.py
# @brief Test Cases inserting special characters in fields of the Extended Search tab
# @ingroup suite_srd_sd
from selenium import webdriver
import unittest, time, re

##@brief This class executes tests inserting special characters in the fields on the "Extended Search" tab
class SrdSdSpecialcharaterExtendedsearchtabTc(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        self.driver.implicitly_wait(30)
        config = {}
        execfile("srd_selenium_tests.conf", config)
        self.base_url = config["BASE_URL"]
        self.verificationErrors = []
        self.accept_next_alert = True

    ##@brief This method verifies the results of the special characters searches
    def test_srd_sd_specialcharater_extendedsearchtab_tc(self):
        driver = self.driver
        driver.get(self.base_url + "/view.php")
        driver.find_element_by_xpath("//a[contains(text(),'SRD Home')]").click()
        driver.find_element_by_xpath("//a[contains(text(),'Search / Download')]").click()
        driver.find_element_by_xpath("//a[contains(text(),'Extended Search')]").click()
        time.sleep(2)
        self.assertEqual("SAMATE Reference Dataset", driver.title)
        
        driver.find_element_by_xpath("//input[@name='reference']").send_keys("\"This sentence is wrapped in double quotes.\"")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()
        
        driver.find_element_by_xpath("//input[@name='description']").send_keys("\"This sentence is wrapped in double quotes.\"")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()
        
        driver.find_element_by_xpath("//input[@name='author']").send_keys("\"This sentence is wrapped in double quotes.\"")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='contributor']").send_keys("\"This sentence is wrapped in double quotes.\"")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("'single quotes'")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("'single quotes'")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("'single quotes'")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_name("contributor").send_keys("'single quotes'")
        driver.find_element_by_name("Submit").click()
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("[square brackets]")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("[square brackets]")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("[square brackets]")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_name("contributor").send_keys("[square brackets]")
        driver.find_element_by_name("Submit").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("{curly braces}")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("{curly braces}")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("{curly braces}")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_name("contributor").send_keys("{curly braces}")
        driver.find_element_by_name("Submit").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("<angle brackets>")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("<angle brackets>")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("<angle brackets>")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_name("contributor").send_keys("<angle brackets>")
        driver.find_element_by_name("Submit").click()
        time.sleep(2)
        self.assert_title(driver)
        #
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("<!-- XML comment -->")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()
        
        driver.find_element_by_xpath("//input[@name='description']").send_keys("<!-- XML comment -->")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("<!-- XML comment -->")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()

        driver.find_element_by_name("contributor").send_keys("<!-- XML comment -->")
        driver.find_element_by_name("Submit").click()
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("\"quoted\" segment & ampersand")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()
        driver.find_element_by_xpath("//input[@name='description']").send_keys("\"quoted\" segment & ampersand")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("\"quoted\" segment & ampersand")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_name("contributor").send_keys("\"quoted\" segment & ampersand")
        driver.find_element_by_name("Submit").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("\"A \"quoted\" segment; & (entity); wrapped in quotes\"")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("\"A \"quoted\" segment; & (entity); wrapped in quotes\"")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("\"A \"quoted\" segment; & (entity); wrapped in quotes\"")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_name("contributor").send_keys("\"A \"quoted\" segment; & (entity); wrapped in quotes\"")
        driver.find_element_by_name("Submit").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("\\c:\\mydocs")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("\\c:\\mydocs")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("\\c:\\mydocs")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_name("contributor").send_keys("\\c:\\mydocs")
        driver.find_element_by_name("Submit").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()
        time.sleep(2)
        driver.find_element_by_xpath("//input[@name='reference']").send_keys("Hawai`i")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("Hawai`i")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("Hawai`i")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_name("contributor").send_keys("Hawai`i")
        driver.find_element_by_name("Submit").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("#20")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("#20")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("#20")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_name("contributor").send_keys("#20")
        driver.find_element_by_name("Submit").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()

        driver.find_element_by_xpath("//input[@name='reference']").send_keys("\\/")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()

        driver.find_element_by_xpath("//input[@name='description']").send_keys("\\/")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()

        driver.find_element_by_xpath("//input[@name='author']").send_keys("\\/")
        driver.find_element_by_xpath("//input[@name='Submit']").click()
        time.sleep(2)
        self.assert_title(driver)
        driver.back()

        driver.find_element_by_name("contributor").send_keys("\\/")
        driver.find_element_by_name("Submit").click()
        time.sleep(2)
        self.assert_title(driver)
        
        driver.back()
    
    def assert_title(self, driver):
        self.assertEqual("SAMATE Reference Dataset :: View all test cases", driver.title)

    def assert_search_result(self, driver):
        try: self.assertEqual("View/Download\nDownloads:     \n\nThere is no such test case in the database! Back to the previous page", driver.find_element_by_xpath("//div[@id='content']").text)
        except AssertionError as e: self.verificationErrors.append(str(e))
        try: self.assertEqual("Back to the previous page", driver.find_element_by_xpath("//a[contains(text(),'Back to the previous page')]").text)
        except AssertionError as e: self.verificationErrors.append(str(e))
    
    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
