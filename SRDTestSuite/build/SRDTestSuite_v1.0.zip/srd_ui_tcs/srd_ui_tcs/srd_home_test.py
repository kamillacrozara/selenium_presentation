#!/usr/bin/python
# -*- coding: utf-8 *-*

##@package srd_ui_tcs
# Package with automated User Interface tests using 
# Selenium Webdriver

##@file srd_home_test.py
# @brief Test cases of "SRD Home" SRD page
# @ingroup suite_srd_ui

from selenium import webdriver
from common_ui_tests import common_ui_tests
import unittest, time, re

##@brief This class has user interface tests to the "SRD Home" page
class TCSRDHome(unittest.TestCase):
    def setUp(self):
        #self.driver = webdriver.Remote(desired_capabilities=self.capabilities)
        self.driver = webdriver.Firefox()
        self.driver.implicitly_wait(30)
        config = {}
        execfile("srd_selenium_tests.conf", config)
        self.base_url = config["BASE_URL"]
        self.verificationErrors = []
        self.accept_next_alert = True
    
    ##@brief This method executes tests to verify the elements on the "SRD Home" page
    def test_t_c_s_r_d_home(self):
        driver = self.driver
        driver.get(self.base_url + "/index.php")
        driver.find_element_by_xpath("//a[contains(text(),'SRD Home')]").click()
        time.sleep(2)
        try: self.assertEqual("SAMATE Reference Dataset", driver.title)
        except AssertionError as e: self.verificationErrors.append(str(e))

        common_ui_tests.testSRDMenu(self, driver, self.verificationErrors)

        

        try: self.assertEqual("Welcome to the NIST SAMATE Reference Dataset Project", driver.find_element_by_css_selector("h1").text)
        except AssertionError as e: self.verificationErrors.append(str(e))
        try: self.assertEqual("Browse, download, and search the SRD", driver.find_element_by_css_selector("h2").text)
        except AssertionError as e: self.verificationErrors.append(str(e))
        try: self.assertEqual("How to submit test cases", driver.find_element_by_xpath("//div[@id='content']/h2[2]").text)
        except AssertionError as e: self.verificationErrors.append(str(e))
        try: self.assertEqual("Acknowledgments", driver.find_element_by_xpath("//div[@id='content']/h2[3]").text)
        except AssertionError as e: self.verificationErrors.append(str(e))
        try: self.assertEqual("Other Assurance Tool Test Collections", driver.find_element_by_xpath("//div[@id='content']/h2[4]").text)
        except AssertionError as e: self.verificationErrors.append(str(e))
        
        common_ui_tests.testFooter(self, driver, self.verificationErrors)
        
    
    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
