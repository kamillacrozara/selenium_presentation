#!/usr/bin/python
# -*- coding: utf-8 *-*
##@package common
# @brief Package with common tests that are used in every test cases 