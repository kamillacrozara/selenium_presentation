#!/usr/bin/python
# -*- coding: utf-8 *-*

##@package srd_ui_tcs
# Package with automated User Interface tests using 
# Selenium Webdriver

##@defgroup suite_srd_ui SRD User Interface Suite
# @details Module with SRD User Interface test cases.

##@file suite_srd_ui.py
# @brief Test Suite of User Interface test cases.
# @ingroup suite_srd_ui

import unittest, sys
from srd_ui_tcs import srd_home_test
from srd_ui_tcs import view_download_test
from srd_ui_tcs import search_download_searchtab_test
from srd_ui_tcs import search_download_sourcecodesearchtab_test
from srd_ui_tcs import search_download_extendedsearchtab_test
from srd_ui_tcs import view_testcase_6_page_test
from srd_ui_tcs import view_testcase_148803_page_test
from srd_ui_tcs import more_downloads_test
from srd_ui_tcs import test_suites_test

##Test suite to SRD User Interface tests
# @brief This method add all the test cases to the test suite
def suite():
	suite = unittest.TestSuite()
	suite.addTest(unittest.makeSuite(srd_home_test.TCSRDHome))
	suite.addTest(unittest.makeSuite(view_download_test.TCViewDownload))
	suite.addTest(unittest.makeSuite(search_download_searchtab_test.TCSearchDownloadSearchTab))
	suite.addTest(unittest.makeSuite(search_download_sourcecodesearchtab_test.TCSearchDownloadSourceCodeSearch))
	suite.addTest(unittest.makeSuite(search_download_extendedsearchtab_test.TCSearchDownloadExtendedSearchTab))
	suite.addTest(unittest.makeSuite(view_testcase_6_page_test.TCViewTestCase6Page))
	suite.addTest(unittest.makeSuite(view_testcase_148803_page_test.TCViewTestCase148803Page))
	suite.addTest(unittest.makeSuite(more_downloads_test.TCMoreDownloads))
	suite.addTest(unittest.makeSuite(test_suites_test.TCTestSuites))
	return suite

if __name__ == "__main__": 
	unittest.TextTestRunner(verbosity=2).run(suite())
	