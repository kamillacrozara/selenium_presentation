\mainpage 

# Disclaimer

This software was developed at the *National Institute of Standards and
Technology* by employees of the Federal Government in the course of their
official duties. Pursuant to title 17 Section 105 of the United States
Code this software is not subject to copyright protection and is in the
public domain. SRDSeleniumTests is an experimental system. NIST assumes no
responsibility whatsoever for its use by other parties and makes no
guarantees, expressed or implied, about its quality, reliability, or any
other characteristic. We would appreciate acknowledgment if the software
is used.


## Using Webdriver and Firefox or Chrome: ##

- [Firefox web browser](www.mozilla.org) v >= 24
- [Chrome web browser](www.google.com/chrome/‎) v >= 29 
- [Chrome Driver](https://code.google.com/p/chromedriver/downloads/list) v >= 2.2 
- [Python "selenium" package](https://pypi.python.org/pypi/selenium)
- [Python "requests" package](https://pypi.python.org/pypi/requests)
- Python scripts files

#### Installing Chrome Driver ####

Download the appropriate file: [Chrome Driver](http://code.google.com/p/chromedriver/downloads/list)


And unzip the Chrome Driver in /usr/bin/google-chrome folder.

# Structure

The SRD Selenium Tests is divided in different modules:

- [Test suite of the Search/Download tab](d0/d0b/a00004.html);

- [Test suite to check all the download links of SRD](d7/d46/a00002.html);

- [Test suite of the User Interface](dd/dad/a00005.html); 

- [Light test suite with basic tests](d1/d7c/a00003.html); 


# Executing test #

####Configuring the base URL:####

The base URL to execute the tests can be changed in srd_selenium_tests.conf file. It just need the base url between quotes (e.g. BASE_URL = "http://samate.nist.gov/SRD").

####Running tests using the Selenium Webdriver:####

#### To execute all tests####
~~~~~~~~~~~~~{.py}
$python run_srd_tests.py
~~~~~~~~~~~~~

#### To execute the User Interface tests####
~~~~~~~~~~~~~{.py}
$python run_srd_tests.py ui
~~~~~~~~~~~~~

#### To execute the Search/Download tests####
~~~~~~~~~~~~~{.py}
$python run_srd_tests.py sd
~~~~~~~~~~~~~

#### To check the download links of SRD ####
~~~~~~~~~~~~~{.py}
$python run_srd_tests.py ck
~~~~~~~~~~~~~

#### To execute the light version of tests####
~~~~~~~~~~~~~{.py}
$python run_srd_tests.py lt
~~~~~~~~~~~~~
