#!/usr/bin/python
# -*- coding: utf-8 *-*

##@package srd_checklinks_tcs
# Package with tests of all download links in SRD. 

##@file download_all_tcs_test.py
# @brief Test Cases to verify all the download links in the SRD
# @ingroup suite_srd_ckecklinks
from selenium import webdriver
import unittest
import requests

##@brief This class executes checks all the download links in SRD
class DownloadAllTcs(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        self.driver.implicitly_wait(30)
        
        config = {}
        execfile("srd_test_suite.conf", config)
        self.base_url = config["BASE_URL"]

        self.verificationErrors = []
        self.accept_next_alert = True

    ##@brief This method verifies the download links of all test cases in a page 
    # For each page of test cases (using the default visualization with 20 test cases per page) 
    # verifies the link "Download all test cases on the page".
    def test_download_all_tcs_on_page(self):
        i = 20
        j = 1
        while (i < 88720):
            #the comma in the end of the string is just a little
            #trick to have the "ok" message on the same line. It works!
            #print ("Verifying download link of all tcs on page %s..." %j),

            resp = requests.head(self.base_url + "/view.php?count=20&action=zip-page&first=%s&sort=asc" %i)
            try: 
                self.assertEqual(resp.status_code, 200)
                #print "ok"
            except AssertionError as e: self.verificationErrors.append(str(e))
            i += 20
            j += 1
            
    ##@brief This method verifies the direct download link of all test cases in SRD
    def test_download_all_tcs_on_srd(self):
        resp = requests.head(self.base_url + "/archive/current.zip")
        try: self.assertEqual(resp.status_code, 200)
        except AssertionError as e: self.verificationErrors.append(str(e))
    
    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()