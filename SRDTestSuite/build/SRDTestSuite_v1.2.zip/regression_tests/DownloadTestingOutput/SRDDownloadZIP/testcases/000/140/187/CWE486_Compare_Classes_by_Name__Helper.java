/*
 * @description A helper class for CWE486_Compare_Classes_by_Name__basic_*.java
 * 
 * */

package testcases.CWE486_Compare_Classes_by_Name;

public class CWE486_Compare_Classes_by_Name__Helper 
{
    public String toString() 
    {
        return "testcases.CWE486_Compare_Classes_by_Name.CWE486_Compare_Classes_by_Name__Helper";
    }  
}
