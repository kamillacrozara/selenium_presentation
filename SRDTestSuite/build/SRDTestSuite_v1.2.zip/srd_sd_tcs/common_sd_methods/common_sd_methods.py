#!/usr/bin/python
# -*- coding: utf-8 *-*

##@package srd_sd_tcs
# Package with automated Search/Download tab tests using 
# Selenium Webdriver

##@file common_sd_tests.py
# @brief Common test cases related to the Search/Download tab tests.
# @ingroup suite_srd_sd

def assert_title(self, driver, verificationErrors):
    try: self.assertEqual("SAMATE Reference Dataset :: View all test cases", driver.title)
    except AssertionError as e: verificationErrors.append(str(e))

def assert_search_result(self, driver, verificationErrors):
	try: self.assertEqual("View/Download\nDownloads:     \n\nThere is no such test case in the database! Back to the previous page", driver.find_element_by_xpath("//div[@id='content']").text)
	except AssertionError as e: verificationErrors.append(str(e))
	try: self.assertEqual("Back to the previous page", driver.find_element_by_xpath("//a[contains(text(),'Back to the previous page')]").text)
	except AssertionError as e: verificationErrors.append(str(e))

##@brief This method counts the number of test cases in a given page  
# @param driver Selenium webdriver current object  
def count_test_cases_in_page(driver):
    i = 2
    numOfTestCases = 0

    while(True):
        try:
            driver.find_element_by_xpath("//div[@id='content']/form/table/tbody/tr[%s]/td[2]/a" %i)
            numOfTestCases += 1
            i += 1
        except:
            return numOfTestCases


def go_last_page(driver):
        try:
            driver.find_element_by_xpath("//a[contains(text(),'Last')]").click()
            time.sleep(5)
            return True
        except:
            return None

if __name__ == '__main__':
	main()
