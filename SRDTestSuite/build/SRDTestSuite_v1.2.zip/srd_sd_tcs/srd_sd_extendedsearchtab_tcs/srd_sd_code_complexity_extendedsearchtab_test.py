#!/usr/bin/python
# -*- coding: utf-8 *-*

##@package srd_sd_tcs
# Package with automated Search/Download tab tests using 
# Selenium Webdriver

##@file srd_sd_dropdown_test.py
# @brief Test Cases inserting non-ascii characters in fields of the Extended Search tab
# @ingroup suite_srd_sd
from selenium import webdriver
import unittest, time, re
from srd_sd_tcs.common_sd_methods import common_sd_methods

##@brief This class executes tests inserting non-ascii characters in the fields on the "Extended Search" tab
class SrdSdCodeComplexityExtendedSearchTabTc(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        self.driver.implicitly_wait(5)
        config = {}
        execfile("srd_test_suite.conf", config)
        self.base_url = config["BASE_URL"]
        self.verificationErrors = []
        self.accept_next_alert = True

    ##@brief This method verifies the results of the non-ascii characters searches
    def test_srd_sd_code_complexity_extendedsearchtab_tc(self):
        driver = self.driver

        self.get_page(driver, "/view.php?fromWhere=fromSearch&flaw=Any...&codecplx=address+alias+level&reference=&description=&author=&contributor=&flawed[]=Any...&languages[]=Any...&typesofartifacts[]=Any...&status_Candidate=1&status_Approved=1&typesofflaws_1=Any...&codecplx_1=address+alias+level&date=&typeDate=Any...&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)

        self.get_page(driver, "/view.php?fromWhere=fromSearch&flaw=Any...&codecplx=buffer+address+type&reference=&description=&author=&contributor=&flawed[]=Any...&languages[]=Any...&typesofartifacts[]=Any...&status_Candidate=1&status_Approved=1&typesofflaws_1=Any...&codecplx_1=buffer+address+type&date=&typeDate=Any...&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)

        self.get_page(driver, "/view.php?fromWhere=fromSearch&flaw=Any...&codecplx=memory+location&reference=&description=&author=&contributor=&flawed[]=Any...&languages[]=Any...&typesofartifacts[]=Any...&status_Candidate=1&status_Approved=1&typesofflaws_1=Any...&codecplx_1=memory+location&date=&typeDate=Any...&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)

        self.get_page(driver, "/view.php?fromWhere=fromSearch&flaw=Any...&codecplx=array+index+complexity&reference=&description=&author=&contributor=&flawed[]=Any...&languages[]=Any...&typesofartifacts[]=Any...&status_Candidate=1&status_Approved=1&typesofflaws_1=Any...&codecplx_1=array+index+complexity&date=&typeDate=Any...&Submit=Search+Test+Cases")
        common_sd_methods.assert_title(self, driver, self.verificationErrors)


    def get_page(self, driver, url):
        driver.get(self.base_url + url)
        time.sleep(2)

    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()